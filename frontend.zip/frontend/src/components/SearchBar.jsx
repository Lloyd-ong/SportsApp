function SearchBar({ value, onChange, onSubmit, onClear }) {
  return (
    <form
      className="search-bar"
      onSubmit={(event) => {
        event.preventDefault();
        onSubmit();
      }}
    >
      <input
        type="search"
        placeholder="Search by sport, location, or team vibe"
        value={value}
        onChange={(event) => onChange(event.target.value)}
      />
      <button type="submit" className="btn btn--primary">
        Search
      </button>
      {value ? (
        <button type="button" className="btn btn--ghost" onClick={onClear}>
          Clear
        </button>
      ) : null}
    </form>
  );
}

export default SearchBar;
