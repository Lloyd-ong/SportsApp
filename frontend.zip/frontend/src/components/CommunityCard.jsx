import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getOneMapStaticMapUrl, parseLatLng } from '../utils/onemap.js';
import { getStaticMapUrl } from '../utils/googleMaps.js';
import {
  approveCommunityRequest,
  getCommunityRequests,
  joinCommunity,
  leaveCommunity,
  rejectCommunityRequest,
  updateCommunity
} from '../api.js';

function CommunityCard({ community, canPost, onMembershipChange, onCommunityUpdated }) {
  const [imageError, setImageError] = useState('');
  const [error, setError] = useState('');
  const [joining, setJoining] = useState(false);
  const [requests, setRequests] = useState([]);
  const [requestLoading, setRequestLoading] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [editSaving, setEditSaving] = useState(false);
  const [editForm, setEditForm] = useState({
    name: community.name || '',
    description: community.description || '',
    sport: community.sport || '',
    region: community.region || '',
    image_url: community.image_url || '',
    max_members: community.max_members || '',
    visibility: community.visibility || 'public'
  });
  const isMember = Boolean(community.is_member);
  const isOwner = Boolean(community.is_owner);
  const membershipStatus = community.membership_status || 'none';
  const isPrivate = community.visibility === 'private';
  const createdLabel = community.created_at ? new Date(community.created_at).toLocaleDateString() : '';
  const locationCenter = parseLatLng(community.region || '');
  const googleKey = import.meta.env.VITE_GOOGLE_MAPS_KEY;
  const googleQuery = locationCenter ? `${locationCenter.lat},${locationCenter.lng}` : (community.region || '');
  const googleUrl = googleKey ? getStaticMapUrl(googleQuery, googleKey) : '';
  const imageUrl = googleUrl || getOneMapStaticMapUrl({ width: 640, height: 360, center: locationCenter });
  const hasImage = Boolean(imageUrl);
  const membersLabel = community.max_members
    ? `${community.member_count || 0}/${community.max_members}`
    : `${community.member_count || 0}`;

  useEffect(() => {
    if (!isOwner) {
      return;
    }

    let active = true;
    setRequestLoading(true);
    getCommunityRequests(community.id)
      .then((data) => {
        if (active) {
          setRequests(data.requests || []);
        }
      })
      .catch((err) => {
        if (active) {
          setError(err.message);
        }
      })
      .finally(() => {
        if (active) {
          setRequestLoading(false);
        }
      });

    return () => {
      active = false;
    };
  }, [isOwner, community.id]);

  useEffect(() => {
    setEditForm({
      name: community.name || '',
      description: community.description || '',
      sport: community.sport || '',
      region: community.region || '',
      image_url: community.image_url || '',
      max_members: community.max_members || '',
      visibility: community.visibility || 'public'
    });
  }, [community]);

  const handleJoinLeave = async () => {
    if (!canPost) {
      return;
    }
    setError('');
    setJoining(true);
    try {
      if (isMember) {
        await leaveCommunity(community.id);
        onMembershipChange?.(community.id, 'none');
        setMessages([]);
      } else {
        const data = await joinCommunity(community.id);
        const nextStatus = data.status || (isPrivate ? 'pending' : 'approved');
        onMembershipChange?.(community.id, nextStatus);
        if (nextStatus !== 'approved') {
          setMessages([]);
        }
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setJoining(false);
    }
  };

  const handleApprove = async (userId) => {
    setError('');
    try {
      await approveCommunityRequest(community.id, userId);
      setRequests((prev) => prev.filter((item) => item.user_id !== userId));
    } catch (err) {
      setError(err.message);
    }
  };

  const handleReject = async (userId) => {
    setError('');
    try {
      await rejectCommunityRequest(community.id, userId);
      setRequests((prev) => prev.filter((item) => item.user_id !== userId));
    } catch (err) {
      setError(err.message);
    }
  };

  const handleEditSubmit = async (event) => {
    event.preventDefault();
    setError('');
    setEditSaving(true);
    try {
      const payload = {
        name: editForm.name.trim(),
        description: editForm.description.trim(),
        sport: editForm.sport.trim(),
        region: editForm.region.trim(),
        image_url: editForm.image_url.trim(),
        max_members: editForm.max_members,
        visibility: editForm.visibility
      };
      const data = await updateCommunity(community.id, payload);
      onCommunityUpdated?.(data.community);
      setEditOpen(false);
    } catch (err) {
      setError(err.message);
    } finally {
      setEditSaving(false);
    }
  };

  const handleImageChange = (event) => {
    const file = event.target.files && event.target.files[0];
    if (!file) {
      return;
    }
    if (!file.type.startsWith('image/')) {
      setImageError('Please select an image file.');
      return;
    }
    setImageError('');
    const reader = new FileReader();
    reader.onload = () => {
      setEditForm((prev) => ({ ...prev, image_url: String(reader.result) }));
    };
    reader.onerror = () => {
      setImageError('Failed to read image.');
    };
    reader.readAsDataURL(file);
  };

  return (
    <article className="event-card community-card">
      <div className="event-card__image">
        {hasImage ? (
          <a
            href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
              community.region || community.name
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="event-card__image-link"
          >
            <img src={imageUrl} alt={community.name} loading="lazy" />
          </a>
        ) : (
          <div className="event-card__image-placeholder">
            <span>{community.sport || 'Community'}</span>
          </div>
        )}
      </div>
      <div className="event-card__header">
        <span className="pill">{community.sport || 'Community'}</span>
        <span className="event-card__meta">
          {community.region || 'All regions'} {isPrivate ? '· Private' : community.visibility === 'invite' ? '· Invite only' : '· Public'}
        </span>
      </div>
      <h3>{community.name}</h3>
      <p className="event-card__desc">{community.description || 'No description yet.'}</p>
      <div className="event-card__details">
        <div>
          <div className="event-card__label">Created by</div>
          <div>{community.creator_name}</div>
        </div>
        <div>
          <div className="event-card__label">Members</div>
          <div>{membersLabel}</div>
        </div>
        {createdLabel ? (
          <div>
            <div className="event-card__label">Created</div>
            <div>{createdLabel}</div>
          </div>
        ) : null}
      </div>
      <div className="event-card__footer">
        <div className="event-card__host">Community chat</div>
        <div className="event-card__actions">
          {isOwner ? (
            <button
              type="button"
              className="btn btn--ghost"
              onClick={() => setEditOpen(true)}
            >
              Edit
            </button>
          ) : null}
          <button
            type="button"
            className="btn btn--ghost"
            onClick={handleJoinLeave}
            disabled={joining || !canPost || membershipStatus === 'pending'}
          >
            {isMember ? 'Leave' : membershipStatus === 'pending' ? 'Requested' : 'Join'}
          </button>
          <Link to={`/communities/${community.id}`} className="btn btn--primary">
            View
          </Link>
        </div>
      </div>
      {membershipStatus === 'pending' ? (
        <div className="chat__locked">Request sent. Waiting for approval.</div>
      ) : null}

      {isOwner ? (
        <div className="moderation">
          <div className="moderation__title">Pending requests</div>
          {requestLoading ? <div className="loading">Loading requests...</div> : null}
          {requests.length ? (
            <div className="moderation__list">
              {requests.map((item) => (
                <div className="moderation__item" key={item.user_id}>
                  <div>
                    <div className="moderation__name">{item.user_name}</div>
                    <div className="moderation__meta">{item.user_email}</div>
                  </div>
                  <div className="moderation__actions">
                    <button
                      type="button"
                      className="btn btn--ghost"
                      onClick={() => handleReject(item.user_id)}
                    >
                      Reject
                    </button>
                    <button
                      type="button"
                      className="btn btn--primary"
                      onClick={() => handleApprove(item.user_id)}
                    >
                      Approve
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="chat__empty">No pending requests.</div>
          )}
        </div>
      ) : null}

      {editOpen ? (
        <div className="md-modal-backdrop" role="presentation" onClick={() => setEditOpen(false)}>
          <div
            className="md-modal"
            role="dialog"
            aria-modal="true"
            onClick={(event) => event.stopPropagation()}
          >
            <button
              type="button"
              className="md-modal__close"
              onClick={() => setEditOpen(false)}
              aria-label="Close"
            >
              x
            </button>
            <h2>Edit community</h2>
            <p className="md-modal__lead">Update your community details.</p>
            <form className="community-form" onSubmit={handleEditSubmit}>
              <div className="image-upload">
                <span className="image-upload__label">Community image</span>
                <label className="image-upload__box">
                  {editForm.image_url ? (
                    <img src={editForm.image_url} alt="Community preview" />
                  ) : (
                    <div className="image-upload__placeholder">+</div>
                  )}
                  <input type="file" accept="image/*" onChange={handleImageChange} />
                </label>
                {imageError ? <div className="form-error">{imageError}</div> : null}
              </div>
              <label>
                Name
                <input
                  type="text"
                  value={editForm.name}
                  onChange={(event) => setEditForm((prev) => ({ ...prev, name: event.target.value }))}
                  required
                />
              </label>
              <label>
                Sport
                <input
                  type="text"
                  value={editForm.sport}
                  onChange={(event) => setEditForm((prev) => ({ ...prev, sport: event.target.value }))}
                />
              </label>
              <label>
                Region
                <input
                  type="text"
                  value={editForm.region}
                  onChange={(event) => setEditForm((prev) => ({ ...prev, region: event.target.value }))}
                />
              </label>
              <label>
                Max members
                <input
                  type="number"
                  min="1"
                  value={editForm.max_members}
                  onChange={(event) => setEditForm((prev) => ({ ...prev, max_members: event.target.value }))}
                />
              </label>
                <label>
                  Visibility
                  <select
                    value={editForm.visibility}
                    onChange={(event) => setEditForm((prev) => ({ ...prev, visibility: event.target.value }))}
                  >
                    <option value="public">Public</option>
                    <option value="private">Private</option>
                    <option value="invite">Invite only</option>
                  </select>
                </label>
              <label>
                Description
                <textarea
                  rows="3"
                  value={editForm.description}
                  onChange={(event) => setEditForm((prev) => ({ ...prev, description: event.target.value }))}
                />
              </label>
              <button type="submit" className="btn btn--primary" disabled={editSaving}>
                {editSaving ? 'Saving...' : 'Save changes'}
              </button>
            </form>
          </div>
        </div>
      ) : null}
    </article>
  );
}

export default CommunityCard;
