import { Link } from 'react-router-dom';
import { getOneMapStaticMapUrl, parseLatLng } from '../utils/onemap.js';
import { getStaticMapUrl } from '../utils/googleMaps.js';

function EventCard({ event, onToggleRsvp, canRsvp, index }) {
  const startDate = event.start_time ? new Date(event.start_time) : null;
  const endDate = event.end_time ? new Date(event.end_time) : null;
  const dateLabel = startDate && !Number.isNaN(startDate.valueOf())
    ? startDate.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })
    : event.start_time;
  const timeLabel = startDate && !Number.isNaN(startDate.valueOf())
    ? startDate.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })
    : '';
  const endLabel = endDate && !Number.isNaN(endDate.valueOf())
    ? endDate.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })
    : '';

  const rsvpCount = Number(event.rsvp_count) || 0;
  const capacity = event.capacity || null;
  const spotsLeft = capacity ? Math.max(capacity - rsvpCount, 0) : null;
  const isGoing = Boolean(event.is_going);
  const locationCenter = parseLatLng(event.location);
  const locationLabel = event.location ? event.location.replace(/\s*\([^)]*\)\s*$/, '') : '';
  const googleKey = import.meta.env.VITE_GOOGLE_MAPS_KEY;
  const googleQuery = locationCenter ? `${locationCenter.lat},${locationCenter.lng}` : locationLabel;
  const googleUrl = googleKey ? getStaticMapUrl(googleQuery, googleKey) : '';
  const imageUrl = googleUrl || getOneMapStaticMapUrl({ width: 640, height: 360, center: locationCenter });
  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    locationCenter ? `${locationCenter.lat},${locationCenter.lng}` : locationLabel
  )}`;
  const hasImage = Boolean(imageUrl);
  const paxLabel = capacity ? `${rsvpCount}/${capacity}` : `${rsvpCount}`;

  return (
    <article className="event-card" style={{ animationDelay: `${index * 60}ms` }}>
      <Link to={`/events/${event.id}`} className="event-card__link" aria-label={`View ${event.title}`}>
        <div className="event-card__image">
          {hasImage ? (
            <a href={mapsUrl} target="_blank" rel="noopener noreferrer" className="event-card__image-link">
              <img src={imageUrl} alt={event.title} loading="lazy" />
            </a>
          ) : (
            <div className="event-card__image-placeholder">
              <span>{event.sport}</span>
            </div>
          )}
        </div>
      </Link>
      <div className="event-card__header">
        <span className="pill">{event.sport}</span>
        <span className="event-card__meta">
          {dateLabel} {timeLabel}{endLabel ? ` - ${endLabel}` : ''}
        </span>
      </div>
      <h3>
        <Link to={`/events/${event.id}`} className="event-card__title-link">
          {event.title}
        </Link>
      </h3>
      <p className="event-card__desc">{event.description || 'No description yet.'}</p>
      <div className="event-card__details">
        <div>
          <div className="event-card__label">Location</div>
          <div>{locationLabel}</div>
        </div>
        <div>
          <div className="event-card__label">Pax</div>
          <div>{paxLabel}</div>
        </div>
      </div>
      <div className="event-card__footer">
        <div className="event-card__host">
          Hosted by <strong>{event.host_name}</strong>
        </div>
        <div className="event-card__actions">
          <button
            type="button"
            className={`btn ${isGoing ? 'btn--ghost' : 'btn--primary'}`}
            onClick={() => onToggleRsvp(event.id, isGoing)}
            disabled={!canRsvp}
          >
            {isGoing ? 'Cancel RSVP' : 'RSVP'}
          </button>
          <Link to={`/events/${event.id}`} className="btn btn--ghost">
            View details
          </Link>
        </div>
      </div>
    </article>
  );
}

export default EventCard;
