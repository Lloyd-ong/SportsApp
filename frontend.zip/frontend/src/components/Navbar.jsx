import { useState } from 'react';
import { NavLink } from 'react-router-dom';

const logoUrl = '/images/SportAppLogo.png';

function Navbar({ user, onLogout, onOpenAuth }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const initials = user && user.name ? user.name.split(' ').map((part) => part[0]).join('').slice(0, 2) : '';
  const closeMenu = () => setMenuOpen(false);

  return (
    <header className="nav">
      <div className="nav__inner">
        <div className="nav__brand">
          <div className="nav__brand-main">
            <img className="nav__logo-mark" src={logoUrl} alt="PlayNet logo" />
            <span className="nav__logo">PlayNet</span>
          </div>
          <span className="nav__tag">Connect. Share. Grow.</span>
        </div>
        <button
          type="button"
          className="nav__toggle"
          aria-label="Toggle navigation"
          aria-expanded={menuOpen}
          aria-controls="primary-nav"
          onClick={() => setMenuOpen((open) => !open)}
        >
          <span className="nav__toggle-bar" />
          <span className="nav__toggle-bar" />
          <span className="nav__toggle-bar" />
        </button>
        <div className={`nav__panel ${menuOpen ? 'nav__panel--open' : ''}`} id="primary-nav">
          <nav className="nav__links" aria-label="Primary">
            <NavLink
              to="/"
              onClick={closeMenu}
              className={({ isActive }) => `nav__link${isActive ? ' nav__link--active' : ''}`}
            >
              <span className="nav__icon" aria-hidden="true">
                <svg viewBox="0 0 24 24">
                  <path d="M4 10.5L12 4l8 6.5V20a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1v-9.5Z" />
                </svg>
              </span>
              <span className="nav__label">Home</span>
            </NavLink>
            <NavLink
              to="/about"
              onClick={closeMenu}
              className={({ isActive }) => `nav__link${isActive ? ' nav__link--active' : ''}`}
            >
              <span className="nav__icon" aria-hidden="true">
                <svg viewBox="0 0 24 24">
                  <circle cx="12" cy="8" r="3.5" />
                  <path d="M5 20a7 7 0 0 1 14 0" />
                </svg>
              </span>
              <span className="nav__label">About</span>
            </NavLink>
            <NavLink
              to="/contact"
              onClick={closeMenu}
              className={({ isActive }) => `nav__link${isActive ? ' nav__link--active' : ''}`}
            >
              <span className="nav__icon" aria-hidden="true">
                <svg viewBox="0 0 24 24">
                  <path d="M4 6h16v12H4z" />
                  <path d="M4 7l8 6 8-6" />
                </svg>
              </span>
              <span className="nav__label">Contact</span>
            </NavLink>
          </nav>
          <div className="nav__actions">
            {user ? (
              <div className="user-pill">
                <NavLink
                  to="/profile"
                  className="user-pill__link"
                  onClick={closeMenu}
                  aria-label="Open profile"
                >
                  {user.avatar_url ? (
                    <img src={user.avatar_url} alt={user.name} />
                  ) : (
                    <div className="user-pill__initials">{initials || 'ME'}</div>
                  )}
                  <div>
                    <div className="user-pill__name">{user.name}</div>
                  </div>
                </NavLink>
                <button
                  type="button"
                  className="btn btn--ghost"
                  onClick={() => {
                    closeMenu();
                    onLogout();
                  }}
                >
                  Log out
                </button>
              </div>
            ) : (
              <>
                <button
                  type="button"
                  className="btn btn--ghost"
                  onClick={() => {
                    closeMenu();
                    onOpenAuth('login');
                  }}
                >
                  Log in
                </button>
                <button
                  type="button"
                  className="btn btn--primary"
                  onClick={() => {
                    closeMenu();
                    onOpenAuth('register');
                  }}
                >
                  Register
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}

export default Navbar;
