let googleMapsPromise;

export function loadGoogleMaps(apiKey) {
  if (!apiKey) {
    return Promise.reject(new Error('Missing Google Maps API key'));
  }

  if (window.google && window.google.maps) {
    return Promise.resolve(window.google);
  }

  if (googleMapsPromise) {
    return googleMapsPromise;
  }

  googleMapsPromise = new Promise((resolve, reject) => {
    const existing = document.getElementById('google-maps-js');
    if (existing) {
      existing.addEventListener('load', () => resolve(window.google));
      existing.addEventListener('error', () => reject(new Error('Failed to load Google Maps')));
      return;
    }

    const script = document.createElement('script');
    script.id = 'google-maps-js';
    script.async = true;
    script.defer = true;
    script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&loading=async`;
    script.onload = () => resolve(window.google);
    script.onerror = () => reject(new Error('Failed to load Google Maps'));
    document.head.appendChild(script);
  });

  return googleMapsPromise;
}

export function loadGoogleMapsPlaces(apiKey) {
  if (!apiKey) {
    return Promise.reject(new Error('Missing Google Maps API key'));
  }

  if (window.google && window.google.maps && window.google.maps.places) {
    return Promise.resolve(window.google);
  }

  if (googleMapsPromise) {
    return googleMapsPromise;
  }

  googleMapsPromise = new Promise((resolve, reject) => {
    const existing = document.getElementById('google-maps-js');
    if (existing) {
      existing.addEventListener('load', () => resolve(window.google));
      existing.addEventListener('error', () => reject(new Error('Failed to load Google Maps')));
      return;
    }

    const script = document.createElement('script');
    script.id = 'google-maps-js';
    script.async = true;
    script.defer = true;
    script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places&loading=async`;
    script.onload = () => resolve(window.google);
    script.onerror = () => reject(new Error('Failed to load Google Maps'));
    document.head.appendChild(script);
  });

  return googleMapsPromise;
}

export function getStaticMapUrl(location, apiKey) {
  if (!apiKey || !location) {
    return '';
  }
  const query = encodeURIComponent(location);
  return `https://maps.googleapis.com/maps/api/staticmap?center=${query}&zoom=14&size=640x360&maptype=roadmap&markers=color:orange%7C${query}&key=${apiKey}`;
}

export async function initPlaceAutocomplete(inputEl, apiKey, onSelect) {
  if (!inputEl) {
    return () => {};
  }

  const google = await loadGoogleMapsPlaces(apiKey);
  if (google?.maps?.places?.PlaceAutocompleteElement) {
    const wrapper = document.createElement('div');
    wrapper.className = 'gmp-autocomplete';
    const element = new google.maps.places.PlaceAutocompleteElement();
    element.classList.add('gmp-autocomplete__input');
    element.setAttribute('placeholder', inputEl.getAttribute('placeholder') || 'Search location');
    wrapper.appendChild(element);
    inputEl.parentNode.insertBefore(wrapper, inputEl);
    inputEl.style.display = 'none';

    const handlePlace = async (event) => {
      const place = event?.place || event?.detail?.place;
      if (!place) {
        return;
      }
      if (place.fetchFields) {
        await place.fetchFields({ fields: ['formatted_address', 'name', 'displayName'] });
      }
      const value =
        place.formattedAddress || place.displayName || place.name || '';
      if (value) {
        onSelect(value);
      }
    };

    element.addEventListener('gmp-placeselect', handlePlace);
    return () => {
      element.removeEventListener('gmp-placeselect', handlePlace);
      wrapper.remove();
      inputEl.style.display = '';
    };
  }

  if (google?.maps?.places?.Autocomplete) {
    const autocomplete = new google.maps.places.Autocomplete(inputEl, {
      types: ['geocode'],
      fields: ['formatted_address', 'name']
    });
    autocomplete.addListener('place_changed', () => {
      const place = autocomplete.getPlace();
      const value = place.formatted_address || place.name || '';
      if (value) {
        onSelect(value);
      }
    });
    return () => {
      google.maps.event.clearInstanceListeners(autocomplete);
    };
  }

  return () => {};
}

export async function initGoogleMap(container, apiKey, { center, locationLabel } = {}) {
  if (!container) {
    return () => {};
  }
  const google = await loadGoogleMaps(apiKey);
  const defaultCenter = { lat: 1.2868108, lng: 103.8545349 };
  let mapCenter = center || defaultCenter;
  const map = new google.maps.Map(container, {
    center: mapCenter,
    zoom: 14,
    mapTypeControl: false,
    streetViewControl: false,
    fullscreenControl: false
  });
  let marker = new google.maps.Marker({ position: mapCenter, map });

  if (!center && locationLabel) {
    const geocoder = new google.maps.Geocoder();
    geocoder.geocode({ address: locationLabel }, (results, status) => {
      if (status === 'OK' && results && results[0]) {
        const loc = results[0].geometry.location;
        map.setCenter(loc);
        marker.setPosition(loc);
      }
    });
  }

  return () => {
    if (marker) {
      marker.setMap(null);
      marker = null;
    }
  };
}
