const path = require('path');
const dotenv = require('dotenv');
dotenv.config({ path: path.join(__dirname, '.env') });

const express = require('express');
const session = require('express-session');
const cors = require('cors');
const passport = require('passport');
const { router: authRouter, initAuth } = require('./routes/auth');
const eventsRouter = require('./routes/events');
const dashboardRouter = require('./routes/dashboard');
const adminRouter = require('./routes/admin');
const communityRouter = require('./routes/community');
const onemapRouter = require('./routes/onemap');

const app = express();
const port = process.env.PORT || 4000;
const clientOrigin = process.env.CLIENT_ORIGIN || 'http://localhost:5173';
const isProd = process.env.NODE_ENV === 'production';

if (isProd) {
  app.set('trust proxy', 1);
}

app.use(
  cors({
    origin: clientOrigin,
    credentials: true
  })
);

app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: false }));

app.use(
  session({
    secret: process.env.SESSION_SECRET || 'dev_secret',
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: isProd ? 'none' : 'lax',
      secure: isProd
    }
  })
);

initAuth();
app.use(passport.initialize());
app.use(passport.session());

app.get('/health', (req, res) => {
  res.json({ ok: true });
});

app.get('/health/db', async (req, res) => {
  try {
    const db = require('./db');
    await db.query('SELECT 1');
    res.json({ ok: true });
  } catch (err) {
    console.error('DB health check failed', err);
    res.status(500).json({
      ok: false,
      code: err.code,
      message: err.message
    });
  }
});

app.use('/auth', authRouter);
app.use('/api', eventsRouter);
app.use('/api', dashboardRouter);
app.use('/api', adminRouter);
app.use('/api', communityRouter);
app.use('/api', onemapRouter);

app.use((err, req, res, next) => {
  console.error('Unexpected server error', err);
  res.status(500).json({ error: 'Unexpected server error' });
});

app.listen(port, () => {
  console.log(`API running on http://localhost:${port}`);
});
